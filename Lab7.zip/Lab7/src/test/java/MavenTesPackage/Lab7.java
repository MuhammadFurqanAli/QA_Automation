package MavenTesPackage;

import java.time.Duration;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Lab7 {

	public String baseurl = "http://baseline01.curemd.com/curemd/datLogin.asp";
	public WebDriver driver;
	public Lab7POM pom;

	public Actions actions;
	public WebDriverWait wait;
	public Logger log;
	// public Alert alert;
	// public String actual = "", expected = "";
	// configure log4j properties file
    //PropertyConfigurator.configure("Log4j.properties");

	@BeforeTest
	public void goToPage() {
		/// System.setProperty("webdriver.chrome.driver",
		// "C:\\Users\\ACER\\Desktop\\CureMD\\QA_Automation\\Java\\chromedriver.exe");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\4123\\Downloads\\chromedriver.exe");
		// Create New WebDriver and maximize it
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(baseurl);

		pom = new Lab7POM(driver);
		log = LogManager.getLogger(Lab7.class);
		
		//log = Logger.getLogger("addPatientData");
		// Create Actions & Wait Objects
		actions = new Actions(driver);
		wait = new WebDriverWait(driver, Duration.ofSeconds(3));

	}

	@DataProvider(name = "test1data")
	public Object[][] getData() {

		String projectPath = System.getProperty("user.dir");
		Object data[][] = testData(projectPath + "\\Excel\\dataProv.xlsx", "Sheet1");
		return data;
	}

	public Object[][] testData(String excelPath, String sheetName) {

		Lab7POM excel = new Lab7POM(excelPath, sheetName);

		int rowCount = excel.getRowCount();
		int colCount = excel.getColumnCount();

		Object data[][] = new Object[rowCount - 1][colCount];

		for (int i = 1; i < rowCount; i++) { // started with 1 because first is heading
			for (int j = 0; j < colCount; j++) { // started with 0 because first is data
				String cellData = excel.getCellDataString(i, j);
				// System.out.print(cellData+" | ");
				data[i - 1][j] = cellData;
			}
			// System.out.println();
		}
		return data;
	}

	@Test(priority = 0)
	public void login() {

		// String loginPageWindow = driver.getWindowHandle();

		pom.userName.sendKeys("ChargePStatemen");
		log.info("Entered Username in Username Field.");
		pom.password.sendKeys("SuPPort.2014");
		log.info("Entered Password in Password Field.");
		pom.loginButton.click();
		log.info("Clicked Login Button.");
		
		for (String winHan : driver.getWindowHandles()) {
			driver.switchTo().window(winHan);
			log.info("Switched Window Using Window Handles.");
		}

		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.iframeMenu));
		log.info("Swicthed to Menu Frame.");
	}

	@Test(priority = 1)
	public void addPatientButton() {

		pom.patientButton.click();
		log.info("Clicked Patient Button.");
		driver.switchTo().parentFrame();
		log.info("Swicthed to Parent Frame.");
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.driverIframeBody));
		log.info("Swicthed to Body Frame.");
		pom.addButton.click();
		log.info("Clicked Add Button.");
	}

	@Test(priority = 2, dataProvider = "test1data")
	public void addPatientData(String FirstName, String LastName,String DOB) {
		//for(int i=0; i<=)
		//int i=3;
		pom.setCellData(4, "Status");
		
		actions.clickAndHold(pom.titleSelect).perform();
		log.info("Clicked and Hold On to Title Select Dropdown.");
		pom.titleSelectOption.click();
		log.info("Clicked Title Select Option.");
		pom.fName.sendKeys(FirstName);
		log.info("Sent First Name Using DataProviders.");
		pom.lName.sendKeys(LastName);
		log.info("Sent Last Name Using DataProviders.");
		actions.clickAndHold(pom.genderSelect).perform();
		log.info("Clicked and Hold On to Gender Select Dropdown.");
		pom.genderSelectOption.click();
		log.info("Clicked Gender Select Option.");
		pom.dob.sendKeys(DOB);
		log.info("Sent Date As An Input.");
		pom.locationSelect.click();
		log.info("Clicked Location Dropdown.");
		List<WebElement> locationSelectOptions = driver.findElements(pom.locationSelectOption);
		log.info("Made List of All The Options.");
		locationSelectOptions.get(2).click();
		log.info("Clicked Location Option2.");
		pom.saveButton.click();
		log.info("Clicked Save Button.");
		try {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.iframeNewSaveAs));
			pom.saveAsNewButton.click();
			//wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.driverIframeBody));
			driver.switchTo().defaultContent();
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.iframeMenu));
			addPatientButton();
			/*wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.driverIframeBody));
			pom.fName.clear();
			pom.lName.clear();
			pom.saveButton = pom.saveButtonNew;
			//wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.driverIframeBody));
			//driver.switchTo().frame(pom.driverIframeBody);
			*/
		} catch (Exception e) {
			System.out.println("No PopUp Present, Moving To Next Data Provider.");
		}
	}
	
	@Test(priority = 3)
	public void addNewCase() {
		
		
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.iframePatientMenu));
		
		pom.patientSelectHotList.click();
		
		wait.until(ExpectedConditions.visibilityOf(pom.providerNotesPlus)).click();
		//pom.providerNotesPlus.click();
		pom.providerNotesnewCase.click();
		
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.driverIframeBody));
		pom.providerNotesnewCaseNameInput.sendKeys("user");
		//pom.providerNotesnewCaseDateInput.sendKeys("8/24/2022");
		pom.providerNotesnewCaseSaveButton.click();
	}
	
	@Test(priority = 4)
	public void addProviderNotes() {
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.iframePatientMenu));
		pom.providerNotesproviderNotes.click();
		
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(pom.driverIframeBody));
		
		List<WebElement> addProvNoteButtonList = driver.findElements(pom.addProviderNoteButton);
		
		wait.until(ExpectedConditions.visibilityOf(addProvNoteButtonList.get(0)));
		addProvNoteButtonList.get(0).click();
		//pom.providerNotesDateInput.sendKeys("8/24/2022");
		
		wait.until(ExpectedConditions.visibilityOf(pom.providerNotesproviderSelect));
		//pom.providerNotesproviderSelect.click();
		//pom.providerNotesproviderSelect.click();
		pom.providerNotesproviderSelectOption.click();
		
		pom.providerNotesnoteTemplateSelect.click();
		pom.providerNotesnoteTemplateSelectOption.click();
		
		pom.providerNotesvisitReasonSelect.click();
		pom.providerNotesvisitReasonSelectOption.click();
		
		pom.providerNoteslocationSelect.click();
		pom.providerNoteslocationSelectOption.click();
		
		pom.providerNotesnoteTypeSelect.click();
		pom.providerNotesnoteTypeSelectOption.click();
		
		pom.createProviderNoteButton.click();
		
		
	}
	
	@AfterTest
	public void closeDriver() {
		driver.quit();
	}

}
