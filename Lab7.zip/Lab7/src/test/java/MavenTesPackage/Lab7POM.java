package MavenTesPackage;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Lab7POM {

	static String projectPath = "user.dir";
	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	static XSSFCell cell;

	WebDriver driver;

	@FindBy(xpath = "//input[@id='vchLogin_Name']")
	WebElement userName;

	@FindBy(xpath = "//input[@id='vchPassword']")
	WebElement password;

	@FindBy(xpath = "//button[@class='btn btn-danger']")
	WebElement loginButton;

	@FindBy(xpath = "//iframe[@id='fraCureMD_Menu']")
	WebElement iframeMenu;

	@FindBy(xpath = "//img[@id='patientBtn']")
	WebElement patientButton;

	@FindBy(xpath = "//iframe[@id='fraCureMD_Body']")
	WebElement driverIframeBody;

	@FindBy(xpath = "//td[@title='Add Patient']")
	WebElement addButton;

	@FindBy(xpath = "//select[@id='cmbVTitle']")
	WebElement titleSelect;

	@FindBy(xpath = "//select[@id='cmbVTitle']//option[text()='Prof']")
	WebElement titleSelectOption;

	@FindBy(xpath = "//input[@id='txtVFNAME']")
	WebElement fName;

	@FindBy(xpath = "//input[@id='txtVLNAME']")
	WebElement lName;

	@FindBy(xpath = "//select[@id='cmbVSEX']")
	WebElement genderSelect;

	@FindBy(xpath = "//select[@id='cmbVSEX']//option[@value='O']")
	WebElement genderSelectOption;

	@FindBy(xpath = "//input[@id='txtDDOB']")
	WebElement dob;

	@FindBy(xpath = "//span[@role='presentation']")
	WebElement locationSelect;

	// @FindBy(xpath = "//select[@id='cmbILOCID']//option")
	// WebElement locationSelectOption;

	By locationSelectOption = By.xpath("//select[@id='cmbILOCID']//option");

	@FindBy(xpath = "//td[@id='tdsave']")
	WebElement saveButton;

	@FindBy(xpath = "//iframe[@id='DynamicBHdialogbox']\n")
	WebElement iframeNewSaveAs;

	@FindBy(xpath = "//button[@id='saveAsNewButton']")
	WebElement saveAsNewButton;

	@FindBy(xpath = "//td[@id='btnActual']")
	WebElement saveButtonNew;

	@FindBy(xpath = "//iframe[@id='fraCureMD_Patient_Menu']")
	WebElement iframePatientMenu;

	@FindBy(xpath = "//span[text()='A, A ']")
	WebElement patientSelectHotList;

	@FindBy(xpath = "//strong[text()='Provider Notes']//parent::label//parent::div//img")
	WebElement providerNotesPlus;

	@FindBy(xpath = "//label[text()='New Case']")
	WebElement providerNotesnewCase;

	@FindBy(xpath = "//input[@id='txtVCNAME']")
	WebElement providerNotesnewCaseNameInput;

	@FindBy(xpath = "//input[@id='txtDSTART']")
	WebElement providerNotesnewCaseDateInput;

	@FindBy(xpath = "//td[@id='cmdSubmit']")
	WebElement providerNotesnewCaseSaveButton;

	@FindBy(xpath = "//label[contains(@onclick,'Provider')]")
	WebElement providerNotesproviderNotes;

	// @FindBy(xpath="//td[@class='ButtonItem' and contains(@id,'SpAdd')]")
	// WebElement addProviderNoteButton;
	By addProviderNoteButton = By.xpath("//td[@class='ButtonItem' and contains(@id,'SpAdd')]");

	@FindBy(xpath = "//input[@id='Sdate']")
	WebElement providerNotesDateInput;

	@FindBy(xpath = "//span[contains(@id,'cmbProvider-container')]//following-sibling::span")
	// span[@title=\"--Select--\"]
	WebElement providerNotesproviderSelect;

	// By provideSelectOption =
	// By.xpath("//select[@id=\\\"cmbProvider\\\"]//child::option");

	@FindBy(xpath = "//select[@id='cmbProvider']//child::option[text()='BillingProvider, test']")
	WebElement providerNotesproviderSelectOption;

	@FindBy(xpath = "//select[@id='cmbRTemplate']")
	WebElement providerNotesnoteTemplateSelect;

	@FindBy(xpath = "//select[@id='cmbRTemplate']//option[text()='Immunization Field Max']")
	WebElement providerNotesnoteTemplateSelectOption;

	@FindBy(xpath = "//select[@id='txtVREASON']")
	WebElement providerNotesvisitReasonSelect;

	@FindBy(xpath = "//select[@id='txtVREASON']//option[text()='Accident']")
	WebElement providerNotesvisitReasonSelectOption;

	@FindBy(xpath = "//span[contains(@id,'cmbLocation-container')]//following-sibling::span")
	WebElement providerNoteslocationSelect;

	@FindBy(xpath = "//select[@id='cmbLocation']//option[text()='Clinic One1']")
	WebElement providerNoteslocationSelectOption;

	@FindBy(xpath = "//select[@id='cmbReportType']")
	WebElement providerNotesnoteTypeSelect;

	@FindBy(xpath = "//select[@id='cmbReportType']//option[text()='Admit Note']")
	WebElement providerNotesnoteTypeSelectOption;

	@FindBy(xpath = "//td[@id='btnSave']")
	WebElement createProviderNoteButton;

	// select[@id='cmbReportType']

	public Lab7POM(WebDriver driver) {
		try {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		} catch (Exception e) {

			System.out.println(e.getMessage());
			System.out.println(e.getCause());
			e.printStackTrace();
		}
	}

	public Lab7POM(String excelPath, String sheetName) {
		try {
			workbook = new XSSFWorkbook(excelPath);
			sheet = workbook.getSheet(sheetName);
		} catch (Exception e) {

			System.out.println(e.getMessage());
			System.out.println(e.getCause());
			e.printStackTrace();
		}
	}

	public static void getExcelSheet() {

		try {
			workbook = new XSSFWorkbook(projectPath + "\\Excel\\dataProv.xlsx");
			sheet = workbook.getSheet("Sheet1");
		} catch (Exception e) {

			System.out.println(e.getMessage());
			System.out.println(e.getCause());
			e.printStackTrace();
		}
	}

	public static int getRowCount() {

		int rowCount = sheet.getPhysicalNumberOfRows();
		System.out.println("Number of rows are: " + rowCount);
		return rowCount;
	}

	public static int getColumnCount() {

		int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
		System.out.println("Number of Columns are: " + colCount);
		return colCount;
	}

	public static double getCellDataNumeric(int row, int col) {

		double cellDataNum = sheet.getRow(row).getCell(col).getNumericCellValue();
		// System.out.println("Number At Given Cell is: " + cellData);
		return cellDataNum;
	}

	public static String getCellDataString(int row, int col) {

		String cellDataStr = sheet.getRow(row).getCell(col).getStringCellValue();
		// System.out.println("String At Given Cell is: " + cellData);
		return cellDataStr;
	}

	public void setCellData(int row, String inp) {

		cell = sheet.getRow(row).createCell(4);
		cell.setCellValue(inp);
		// sheet.getRow(row).getCell(col).setCellValue(inp);

	}
}